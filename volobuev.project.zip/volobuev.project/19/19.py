import numpy as np
from keras.preprocessing import image
from tensorflow.keras.models import load_model
import re
import random
a11 = []
b11 = []
c11 = []
c22 = []
c33 = []
c44 = []
d11 = []
d22 = []
e11 = []
e22 = []
q11 = []
g11 = []
g22 = []
g33 = []
g44 = []
h11 = []
h22 = []
h33 = []
i11 = []
i22 = []
i33 = []
j11 = []
k11 = []
k22 = []
k33 = []
m11 = []
m22 = []
m33 = []
s11 = []
s22 = []
s33 = []
t11 = []
t22 = []
t33 = []
t44 = []
u11 = []
o11 = []
o22 = []
o33 = []
p11 = []
p22 = []
n11 = []
r11 = []

path = ()
img = image.load_img(path, target_size=(150, 150))
x = image.img_to_array(img)
x = np.expand_dims(x, axis=0)
model = load_model("19.h5")

images = np.vstack([x])
classes = model.predict(images, batch_size=10)
stroka0 = ((str(classes)).replace('[', '').replace(']', ''))
spisok = stroka0.split(' ')
pust1 = ''
pust2 = ' '
for elem in spisok:
    if elem == pust1:
        spisok.remove(elem)
for elem in spisok:
    if elem == pust2:
        spisok.remove(elem)
if spisok[0] == '0' or spisok[0] == '0.0000000e+00' or spisok[0] == '0.0000000e+00\n' or spisok[0] == '0.' or spisok[0] == '0.000000e+00' or spisok[0] == '0.000000e+00\n':
    a = 0
else:
    a = 1
if spisok[1] == '0' or spisok[1] == '0.0000000e+00' or spisok[1] == '0.0000000e+00\n' or spisok[1] == '0.' or spisok[1] == '0.000000e+00' or spisok[1] == '0.000000e+00\n':
    b = 0
else:
    b = 1
if spisok[2] == '0' or spisok[2] == '0.0000000e+00' or spisok[2] == '0.0000000e+00\n' or spisok[2] == '0.' or spisok[2] == '0.000000e+00' or spisok[2] == '0.000000e+00\n':
    c = 0
else:
    c = 1
if spisok[3] == '0' or spisok[3] == '0.0000000e+00' or spisok[3] == '0.0000000e+00\n' or spisok[3] == '0.' or spisok[3] == '0.000000e+00' or spisok[3] == '0.000000e+00\n':
    d = 0
else:
    d = 1
if spisok[4] == '0' or spisok[4] == '0.0000000e+00' or spisok[4] == '0.0000000e+00\n' or spisok[4] == '0.' or spisok[4] == '0.000000e+00' or spisok[4] == '0.000000e+00\n':
    e = 0
else:
    e = 1
if spisok[5] == '0' or spisok[5] == '0.0000000e+00' or spisok[5] == '0.0000000e+00\n' or spisok[5] == '0.' or spisok[5] == '0.000000e+00' or spisok[5] == '0.000000e+00\n':
    q = 0
else:
    q = 1
if spisok[6] == '0' or spisok[6] == '0.0000000e+00' or spisok[6] == '0.0000000e+00\n' or spisok[6] == '0.' or spisok[6] == '0.000000e+00' or spisok[6] == '0.000000e+00\n':
    g = 0
else:
    g = 1
if spisok[7] == '0' or spisok[7] == '0.0000000e+00' or spisok[7] == '0.0000000e+00\n' or spisok[7] == '0.' or spisok[7] == '0.000000e+00' or spisok[7] == '0.000000e+00\n':
    h = 0
else:
    h = 1
if spisok[8] == '0' or spisok[8] == '0.0000000e+00' or spisok[8] == '0.0000000e+00\n' or spisok[8] == '0.' or spisok[8] == '0.000000e+00' or spisok[8] == '0.000000e+00\n':
    i = 0
else:
    i = 1
if spisok[9] == '0' or spisok[9] == '0.0000000e+00' or spisok[9] == '0.0000000e+00\n' or spisok[9] == '0.' or spisok[9] == '0.000000e+00' or spisok[9] == '0.000000e+00\n':
    j = 0
else:
    j = 1
if spisok[10] == '0' or spisok[10] == '0.0000000e+00' or spisok[10] == '0.0000000e+00\n' or spisok[10] == '0.' or spisok[10] == '0.000000e+00' or spisok[10] == '0.000000e+00\n':
    k = 0
else:
    k = 1
if spisok[11] == '0' or spisok[11] == '0.0000000e+00' or spisok[11] == '0.0000000e+00\n' or spisok[11] == '0.' or spisok[11] == '0.000000e+00' or spisok[11] == '0.000000e+00\n':
    p = 0
else:
    p = 1
if spisok[12] == '0' or spisok[12] == '0.0000000e+00' or spisok[12] == '0.0000000e+00\n' or spisok[12] == '0.' or spisok[12] == '0.000000e+00' or spisok[12] == '0.000000e+00\n':
    m = 0
else:
    m = 1
if spisok[13] == '0' or spisok[13] == '0.0000000e+00' or spisok[13] == '0.0000000e+00\n' or spisok[13] == '0.' or spisok[13] == '0.000000e+00' or spisok[13] == '0.000000e+00\n':
    n = 0
else:
    n = 1
if spisok[14] == '0' or spisok[14] == '0.0000000e+00' or spisok[14] == '0.0000000e+00\n' or spisok[14] == '0.' or spisok[14] == '0.000000e+00' or spisok[14] == '0.000000e+00\n':
    o = 0
else:
    o = 1
if spisok[15] == '0' or spisok[15] == '0.0000000e+00' or spisok[15] == '0.0000000e+00\n' or spisok[15] == '0.' or spisok[15] == '0.000000e+00' or spisok[15] == '0.000000e+00\n':
    r = 0
else:
    r = 1
if spisok[16] == '0' or spisok[16] == '0.0000000e+00' or spisok[16] == '0.0000000e+00\n' or spisok[16] == '0.' or spisok[16] == '0.000000e+00' or spisok[16] == '0.000000e+00\n':
    s = 0
else:
    s = 1
if spisok[17] == '0' or spisok[17] == '0.0000000e+00' or spisok[17] == '0.0000000e+00\n' or spisok[17] == '0.' or spisok[17] == '0.000000e+00' or spisok[17] == '0.000000e+00\n':
    t = 0
else:
    t = 1
if spisok[18] == '0' or spisok[18] == '0.0000000e+00' or spisok[18] == '0.0000000e+00\n' or spisok[18] == '0.' or spisok[18] == '0.000000e+00' or spisok[18] == '0.000000e+00\n':
    u = 0
else:
    u = 1



if a == 1:
    a1 = 'pet'
    print('ANIMAL')
if c == 1:
    c1 = 'car'
    c2 = 'money'
    c3 = 'success'
    c4 = 'technology'
    print('CAR')
if d == 1:
    d1 = 'pet'
    d2 = 'home'
    print('CAT')
if e == 1:
    e1 = 'design'
    e2 = 'beauty'
    print('CLOTHES')
if q == 1:
    q1 = 'pet'
    print('DOG')
if g == 1:
    g1 = 'family'
    g2 = 'friendship'
    g3 = 'love'
    g4 = 'relationship'
    print('FAMILY, FRIENDS')
if h == 1:
    h1 = 'beauty'
    h2 = 'romantic'
    h3 = 'nature'
    print('FLOWERS')
if i == 1:
    i1 = 'food'
    i2 = 'diet'
    i3 = 'health'
    print('FOOD')
if j == 1:
    j1 = 'home'
    print('HOME')
if k == 1:
    k1 = 'men'
    k2 = 'power'
    k3 = 'strength'
    print('MAN')
if m == 1:
    m1 = 'nature'
    m2 = 'travel'
    m3 = 'freedom'
    print('NATURE')
if s == 1:
    s1 = 'sports'
    s2 = 'fitness'
    s3 = 'health'
    print('SPORT')
if t == 1:
    t1 = 'architecture'
    t2 = 'morning'
    t3 = 'time'
    t4 = 'society'
    print('TOWN')
if u == 1:
    u1 = 'women'
    print('WOMAN')
if b == 1:
    b1 = 'architecture'
    print('ARCHITECTURE')
if o == 1:
    o1 = 'food'
    o2 = 'money'
    o3 = 'travel'
    print('RESTAURANT')
if p == 1:
    p1 = 'health'
    p2 = 'medical'
    print('MASKED PEOPLE')
if n == 1:
    n1 = 'art'
    print('PICTURE')
if r == 1:
    r1 = 'travel'
    print('SEA, BEACH, BOAT')

if a == b == c == d == e == q == g == h == i == j == k == p == m == n == o == r == s == t == u == 0:
    print('Попробуйте другое изображение')

s = []
with open('цитаты120к.txt') as f:
    lines = f.readlines()
for elem in lines:
    elem = re.sub(r'\s+', ' ', elem)
    elem = elem.rstrip()
    elem = elem.split(' ')
    if a == 1:
        if elem[-1] == a1:
            elem = elem[0:-1]
            strokaa1 = ' '.join(elem)
            a11.append(strokaa1)
    if c == 1:
        if elem[-1] == c1:
            elem = elem[0:-1]
            strokac1 = ' '.join(elem)
            c11.append(strokac1)
        if elem[-1] == c2:
            elem = elem[0:-1]
            strokac2 = ' '.join(elem)
            c22.append(strokac2)
        if elem[-1] == c3:
            elem = elem[0:-1]
            strokac3 = ' '.join(elem)
            c33.append(strokac3)
        if elem[-1] == c4:
            elem = elem[0:-1]
            strokac4 = ' '.join(elem)
            c44.append(strokac4)
    if e == 1:
        if elem[-1] == e1:
            elem = elem[0:-1]
            strokae1 = ' '.join(elem)
            e11.append(strokae1)
        if elem[-1] == e2:
            elem = elem[0:-1]
            strokae2 = ' '.join(elem)
            e22.append(strokae2)
    if d == 1:
        if elem[-1] == d1:
            elem = elem[0:-1]
            strokad1 = ' '.join(elem)
            d11.append(strokad1)
        if elem[-1] == d2:
            elem = elem[0:-1]
            strokad2 = ' '.join(elem)
            d22.append(strokad2)
    if b == 1:
        if elem[-1] == b1:
            elem = elem[0:-1]
            strokab1 = ' '.join(elem)
            b11.append(strokab1)
    if g == 1:
        if elem[-1] == g1:
            elem = elem[0:-1]
            strokag1 = ' '.join(elem)
            g11.append(strokag1)
        if elem[-1] == g2:
            elem = elem[0:-1]
            strokag2 = ' '.join(elem)
            g22.append(strokag2)
        if elem[-1] == g3:
            elem = elem[0:-1]
            strokag3 = ' '.join(elem)
            g33.append(strokag3)
        if elem[-1] == g4:
            elem = elem[0:-1]
            strokag4 = ' '.join(elem)
            g44.append(strokag4)
    if o == 1:
        if elem[-1] == o1:
            elem = elem[0:-1]
            strokao1 = ' '.join(elem)
            o11.append(strokao1)
        if elem[-1] == o2:
            elem = elem[0:-1]
            strokao2 = ' '.join(elem)
            o22.append(strokao2)
        if elem[-1] == o3:
            elem = elem[0:-1]
            strokao3 = ' '.join(elem)
            o33.append(strokao3)
    if h == 1:
        if elem[-1] == h1:
            elem = elem[0:-1]
            strokah1 = ' '.join(elem)
            h11.append(strokah1)
        if elem[-1] == h2:
            elem = elem[0:-1]
            strokah2 = ' '.join(elem)
            h22.append(strokah2)
        if elem[-1] == h3:
            elem = elem[0:-1]
            strokah3 = ' '.join(elem)
            h33.append(strokah3)
    if i == 1:
        if elem[-1] == i1:
            elem = elem[0:-1]
            strokai1 = ' '.join(elem)
            i11.append(strokai1)
        if elem[-1] == i2:
            elem = elem[0:-1]
            strokai2 = ' '.join(elem)
            i22.append(strokai2)
        if elem[-1] == i3:
            elem = elem[0:-1]
            strokai3 = ' '.join(elem)
            i33.append(strokai3)
    if s == 1:
        if elem[-1] == s1:
            elem = elem[0:-1]
            strokas1 = ' '.join(elem)
            s11.append(strokas1)
        if elem[-1] == s2:
            elem = elem[0:-1]
            strokas2 = ' '.join(elem)
            s22.append(strokas2)
        if elem[-1] == s3:
            elem = elem[0:-1]
            strokas3 = ' '.join(elem)
            s33.append(strokas3)
    if k == 1:
        if elem[-1] == k1:
            elem = elem[0:-1]
            strokak1 = ' '.join(elem)
            k11.append(strokak1)
        if elem[-1] == k2:
            elem = elem[0:-1]
            strokak2 = ' '.join(elem)
            k22.append(strokak2)
        if elem[-1] == k3:
            elem = elem[0:-1]
            strokak3 = ' '.join(elem)
            k33.append(strokak3)
    if t == 1:
        if elem[-1] == t1:
            elem = elem[0:-1]
            strokat1 = ' '.join(elem)
            t11.append(strokat1)
        if elem[-1] == t2:
            elem = elem[0:-1]
            strokat2 = ' '.join(elem)
            t22.append(strokat2)
        if elem[-1] == t3:
            elem = elem[0:-1]
            strokat3 = ' '.join(elem)
            t33.append(strokat3)
        if elem[-1] == t4:
            elem = elem[0:-1]
            strokat4 = ' '.join(elem)
            t44.append(strokat4)
    if n == 1:
        if elem[-1] == n1:
            elem = elem[0:-1]
            strokan1 = ' '.join(elem)
            n11.append(strokan1)
    if q == 1:
        if elem[-1] == q1:
            elem = elem[0:-1]
            strokaq1 = ' '.join(elem)
            q11.append(strokaq1)
    if j == 1:
        if elem[-1] == j1:
            elem = elem[0:-1]
            strokaj1 = ' '.join(elem)
            j11.append(strokaj1)
    if m == 1:
        if elem[-1] == m1:
            elem = elem[0:-1]
            strokam1 = ' '.join(elem)
            m11.append(strokam1)
        if elem[-1] == m2:
            elem = elem[0:-1]
            strokam2 = ' '.join(elem)
            m22.append(strokam2)
        if elem[-1] == m3:
            elem = elem[0:-1]
            strokam3 = ' '.join(elem)
            m33.append(strokam3)
    if u == 1:
        if elem[-1] == u1:
            elem = elem[0:-1]
            strokau1 = ' '.join(elem)
            u11.append(strokau1)
    if r == 1:
        if elem[-1] == r1:
            elem = elem[0:-1]
            strokar1 = ' '.join(elem)
            r11.append(strokar1)
    if p == 1:
        if elem[-1] == p1:
            elem = elem[0:-1]
            strokap1 = ' '.join(elem)
            p11.append(strokap1)
        if elem[-1] == p2:
            elem = elem[0:-1]
            strokap2 = ' '.join(elem)
            p22.append(strokap2)


if a11 != []:
    print('(' + a1 + ')')
    for i in (random.choices(a11, k=3)):
        i = ''.join(i)
        print(i)
    print('')
if c11 != []:
    print('(' + c1 + ')')
    for i in (random.choices(c11, k=3)):
        i = ''.join(i)
        print(i)
    print('')
if c22 != []:
    print('(' + c2 + ')')
    for i in (random.choices(c22, k=3)):
        i = ''.join(i)
        print(i)
    print('')
if c33 != []:
    print('(' + c3 + ')')
    for i in (random.choices(c33, k=3)):
        i = ''.join(i)
        print(i)
    print('')
if c44 != []:
    print('(' + c4 + ')')
    for i in (random.choices(c44, k=3)):
        i = ''.join(i)
        print(i)
    print('')
if d11 != []:
    print('(' + d1 + ')')
    for i in (random.choices(d11, k=3)):
        i = ''.join(i)
        print(i)
    print('')
if d22 != []:
    print('(' + d2 + ')')
    for i in (random.choices(d22, k=3)):
        i = ''.join(i)
        print(i)
    print('')
if e11 != []:
    print('(' + e1 + ')')
    for i in (random.choices(e11, k=3)):
        i = ''.join(i)
        print(i)
    print('')
if e22 != []:
    print('(' + e2 + ')')
    for i in (random.choices(e22, k=3)):
        i = ''.join(i)
        print(i)
    print('')
if q11 != []:
    print('(' + q1 + ')')
    for i in (random.choices(q11, k=3)):
        i = ''.join(i)
        print(i)
    print('')
if g11 != []:
    print('(' + g1 + ')')
    for i in (random.choices(g11, k=3)):
        i = ''.join(i)
        print(i)
    print('')
if g22 != []:
    print('(' + g2 + ')')
    for i in (random.choices(g22, k=3)):
        i = ''.join(i)
        print(i)
    print('')
if g33 != []:
    print('(' + g3 + ')')
    for i in (random.choices(g33, k=3)):
        i = ''.join(i)
        print(i)
    print('')
if g44 != []:
    print('(' + g4 + ')')
    for i in (random.choices(g44, k=3)):
        i = ''.join(i)
        print(i)
    print('')
if o11 != []:
    print('(' + o1 + ')')
    for i in (random.choices(o11, k=3)):
        i = ''.join(i)
        print(i)
    print('')
if o22 != []:
    print('(' + o2 + ')')
    for i in (random.choices(o22, k=3)):
        i = ''.join(i)
        print(i)
    print('')
if o33 != []:
    print('(' + o3 + ')')
    for i in (random.choices(o33, k=3)):
        i = ''.join(i)
        print(i)
    print('')
if h11 != []:
    print('(' + h1 + ')')
    for i in (random.choices(h11, k=3)):
        i = ''.join(i)
        print(i)
    print('')
if h22 != []:
    print('(' + h2 + ')')
    for i in (random.choices(h22, k=3)):
        i = ''.join(i)
        print(i)
    print('')
if h33 != []:
    print('(' + h3 + ')')
    for i in (random.choices(h33, k=3)):
        i = ''.join(i)
        print(i)
    print('')
if i11 != []:
    print('(' + i1 + ')')
    for i in (random.choices(i11, k=3)):
        i = ''.join(i)
        print(i)
    print('')
if i22 != []:
    print('(' + i2 + ')')
    for i in (random.choices(i22, k=3)):
        i = ''.join(i)
        print(i)
    print('')
if i33 != []:
    print('(' + i3 + ')')
    for i in (random.choices(i33, k=3)):
        i = ''.join(i)
        print(i)
    print('')
if s11 != []:
    print('(' + s1 + ')')
    for i in (random.choices(s11, k=3)):
        i = ''.join(i)
        print(i)
    print('')
if s22 != []:
    print('(' + s2 + ')')
    for i in (random.choices(s22, k=3)):
        i = ''.join(i)
        print(i)
    print('')
if s33 != []:
    print('(' + s3 + ')')
    for i in (random.choices(s33, k=3)):
        i = ''.join(i)
        print(i)
    print('')
if k11 != []:
    print('(' + k1 + ')')
    for i in (random.choices(k11, k=3)):
        i = ''.join(i)
        print(i)
    print('')
if k22 != []:
    print('(' + k2 + ')')
    for i in (random.choices(k22, k=3)):
        i = ''.join(i)
        print(i)
    print('')
if k33 != []:
    print('(' + k3 + ')')
    for i in (random.choices(k33, k=3)):
        i = ''.join(i)
        print(i)
    print('')
if t11 != []:
    print('(' + t1 + ')')
    for i in (random.choices(t11, k=3)):
        i = ''.join(i)
        print(i)
    print('')
if t22 != []:
    print('(' + t2 + ')')
    for i in (random.choices(t22, k=3)):
        i = ''.join(i)
        print(i)
    print('')
if t33 != []:
    print('(' + t3 + ')')
    for i in (random.choices(t33, k=3)):
        i = ''.join(i)
        print(i)
    print('')
if t44 != []:
    print('(' + t4 + ')')
    for i in (random.choices(t44, k=3)):
        i = ''.join(i)
        print(i)
    print('')
if m11 != []:
    print('(' + m1 + ')')
    for i in (random.choices(m11, k=3)):
        i = ''.join(i)
        print(i)
    print('')
if j11 != []:
    print('(' + j1 + ')')
    for i in (random.choices(j11, k=3)):
        i = ''.join(i)
        print(i)
    print('')
if u11 != []:
    print('(' + u1 + ')')
    for i in (random.choices(u11, k=3)):
        i = ''.join(i)
        print(i)
    print('')
if b11 != []:
    print('(' + b1 + ')')
    for i in (random.choices(b11, k=3)):
        i = ''.join(i)
        print(i)
    print('')
if p11 != []:
    print('(' + p1 + ')')
    for i in (random.choices(p11, k=3)):
        i = ''.join(i)
        print(i)
    print('')
if p22 != []:
    print('(' + p2 + ')')
    for i in (random.choices(p22, k=3)):
        i = ''.join(i)
        print(i)
    print('')
if n11 != []:
    print('(' + n1 + ')')
    for i in (random.choices(n11, k=3)):
        i = ''.join(i)
        print(i)
    print('')
if r11 != []:
    print('(' + r1 + ')')
    for i in (random.choices(r11, k=3)):
        i = ''.join(i)
        print(i)
    print('')


print(classes)
print(spisok)

